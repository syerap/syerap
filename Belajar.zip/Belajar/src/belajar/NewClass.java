/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package belajar;

/**
 *
 * @author user
 */
public class NewClass {
    public static void main(String[] arg) {
        long NIK = 357501805010005L;
        String nama = "Asyadulloh";
        String tempatlahir = "Pasuruan";
        String tanggallahir = "18/05/2001";
        String kelamin = "laki-laki";
        String alamat = "Jl KH Achmad dahlan";
        int Rt = 002;
        int Rw = 004;
        String desa = "Pohjentrek";
        String kecamatan = "Purworejo";
        String Kota  = "Pasuruan";
        String agama = "Islam";
        String status = "Belum Kawin";
        String pekerjaan = "Wiraswasta";
        String kewarganegaraan = "WNI";
        long NIM = 201969040005l;
        String prodi = "Teknik Informatika";
        int semester = 1;
        int angkatan = 2019;
        System.out.println("NIK : "+NIK);
        System.out.println("Nama lengkap : "+nama);
        System.out.println("Tmpat. tanggal lahir :"+tempatlahir+", "+tanggallahir);
        System.out.println("Jenis kelamin : "+kelamin);
        System.out.println("Alamat : "+alamat);
        System.out.println("RT/RW : "+Rt+"/"+Rw);
        System.out.println("Desa : "+desa);
        System.out.println("Kecamatan : "+kecamatan);
        System.out.println("Kota : "+Kota);
        System.out.println("Agama : "+agama);
        System.out.println("Status : "+status);
        System.out.println("Pekerjaan : "+pekerjaan);
        System.out.println("Kewarganegaraan "+kewarganegaraan);
        System.out.println("NIM : "+NIM);
        System.out.println("Prodi :"+prodi);
        System.out.println("Angkatan :"+angkatan);
    }

}
